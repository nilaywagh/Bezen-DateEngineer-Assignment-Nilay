1)How to Run
	open nilay.ipynb file in any python ide of this folder which have both data and code file.

2)pip requirements
numpy
pandas
matplotlib